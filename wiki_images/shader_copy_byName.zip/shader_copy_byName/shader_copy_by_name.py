import bpy

srcTgts = {}
for obj in bpy.data.objects:
    if obj.type != "MESH":
        continue
    if "." in obj.name:
        srcName = ".".join(obj.name.split(".")[:-1])
        if srcName not in bpy.data.objects:
            continue
        src = bpy.data.objects[srcName]
        if src not in srcTgts:
            srcTgts[src] = []
        srcTgts[src].append(obj)

for src, tgts in srcTgts.items():
    for tgt in tgts:
        tgt.active_material = src.active_material
